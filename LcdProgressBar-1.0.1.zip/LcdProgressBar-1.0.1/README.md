# What is LcdProgressBar?
LcdProgressBar is an Arduino library for displaying a progress bar in LCD display.

# Dependencies
The LCD display must be previously initialized. This library uses LiquidCrystal library for displaying.

For more information, refer to the [LcdProgressBar Wiki](https://github.com/wloche/LcdProgressBar/wiki).

# Authors and Contributors
* [Wilfried Loche](https://github.com/wloche)

# Support or Contact
* [Wilfried Loche](https://github.com/wloche)
