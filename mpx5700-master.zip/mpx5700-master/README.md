# mpx5700
A Library to interface the MPX5700 series pressure sensor | any other sensor that has capabilities from 0-700kpa 
library includes: Working functions such as getKpa, getPsi, getVac, maxPsi, maxVac  .... setWarnPsi is still needed to be integrated with a hardware component
